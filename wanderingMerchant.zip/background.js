// background.js (Manifest V3 Service Worker)
const API_BASE = "https://api.korlark.com/lostark/merchant/reports";
const STORAGE_KEY_NOTIFY = "notifyEnabled";
const ALARM_NAME = "period-start-check";

const POLLING_INTERVAL = 10 * 60 * 1000; // 10분 간격

const TIME_PERIODS = [
  { start: { h: 4, m: 0 }, end: { h: 9, m: 30 }, name: "04:00~09:30" },
  { start: { h: 10, m: 0 }, end: { h: 15, m: 30 }, name: "10:00~15:30" },
  { start: { h: 16, m: 0 }, end: { h: 21, m: 30 }, name: "16:00~21:30" },
  {
    start: { h: 22, m: 0 },
    end: { h: 3, m: 30, nextDay: true },
    name: "22:00~03:30",
  },
];

function normalizeName(name) {
  return String(name || "")
    .replaceAll(/\s+/g, "")
    .replaceAll(",", "");
}

const SET_NAME_ITEM_KEYS = new Set(
  [
    "샨디",
    "아제나&이난나",
    "니나브",
    "카단",
    "바훈투르",
    "실리안",
    "웨이",
    "발탄",
    "일리아칸",
    "비아키스",
    "아브렐슈드",
    "카멘",
    "쿠크세이튼",
    "베아트리스",
    "에스더 루테란",
    "에버그레이스",
    "페데리코",
    "미한",
    "가디언 루",
    "파한",
    "호동",
    "객주도사",
    "월향도사",
    "수령도사",
    "에스더 시엔",
    "부활하는 카제로스",
    "춤추는 쿠크세이튼",
    "교활한 카마인",
    "심연의 방랑자",
    "각성한 진저웨일",
    "유적을 찾은 카단",
    "에키드나",
    "악몽의 아브렐슈드",
    "라제니스를 이끄는 니나브",
    "절망의 카멘",
    "진저웨일",
    "광기를 잃은 쿠크세이튼",
    "찢겨진 발탄",
    "피요르긴을 휘두르는 바훈투르",
    "모르페",
    "악몽의 헬카서스",
    "데런 아만",
    "폭풍의 베히모스",
    "전장을 지배하는 아제나",
    "도철을 다루는 웨이",
    "칠흑의 숭배자 킬리네사",
    "타무트",
  ].map(normalizeName),
);

let merchantDataCache = null;

async function getMerchantData() {
  if (merchantDataCache) return merchantDataCache;
  const url = chrome.runtime.getURL("MerchantList.json");
  const res = await fetch(url);
  if (!res.ok) throw new Error("Failed to load MerchantList.json");
  merchantDataCache = await res.json();
  return merchantDataCache;
}

function findItemInMerchantData(merchantData, itemId) {
  if (!merchantData) return null;
  const regions = merchantData?.initialData?.scheme?.regions || [];
  for (const region of regions) {
    for (const item of region.items || []) {
      if (item.id === itemId) {
        const hasSetName =
          !!item.setName || SET_NAME_ITEM_KEYS.has(normalizeName(item.name));
        return {
          ...item,
          setName: hasSetName ? item.setName || "set" : "",
          regionName: region.name,
          npcName: region.npcName,
        };
      }
    }
  }
  return null;
}

async function fetchAndProcessMerchantData() {
  // currentServer 값을 chrome.storage.local에서 비동기로 가져옴
  const st = await chrome.storage.local.get("currentServer");
  const server = st.currentServer ?? 3;

  const url = new URL(API_BASE);
  url.searchParams.set("server", String(server));
  url.searchParams.set("before", new Date().toISOString());
  console.log(
    `[${new Date().toLocaleTimeString()}] API 호출: ${url.toString()}`,
  );
  const res = await fetch(url.toString(), {
    headers: { Accept: "application/json" },
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`HTTP ${res.status}: ${t || res.statusText}`);
  }
  const data = await res.json();
  const merchantData = await getMerchantData();
  const currentTime = new Date();

  const currentSession = data.find((d) => {
    const startTime = new Date(d.startTime);
    const endTime = new Date(d.endTime);
    return currentTime >= startTime && currentTime <= endTime;
  });

  const reports = currentSession ? currentSession.reports : [];
  const hits = [];
  // 서버별 즐겨찾기 로드
  const favKey = `selectedCards_${server}`;
  const favSt = await chrome.storage.local.get(favKey);
  const selectedCardIds = Array.isArray(favSt[favKey])
    ? favSt[favKey].map(String)
    : [];
  const useFavFilter = selectedCardIds.length > 0;

  if (reports && reports.length > 0) {
    for (const report of reports) {
      const itemIds =
        typeof report.itemIds === "string"
          ? report.itemIds.split(" ").filter(Boolean)
          : report.itemIds || [];
      for (const itemId of itemIds) {
        const found = findItemInMerchantData(merchantData, itemId);
        if (!found) continue;
        const matchFav = useFavFilter
          ? selectedCardIds.includes(String(found.id))
          : true;
        if (matchFav) {
          hits.push({
            ...found,
            uniqueId: `${report.id}-${found.id}`,
            regionName: found.regionName,
          });
        }
      }
    }
  }
  return { reports, hits };
}

function getNextStartFromNow() {
  const now = new Date();
  let nextDate = null;
  TIME_PERIODS.forEach((p) => {
    const t = new Date(now);
    t.setHours(p.start.h, p.start.m, 0, 0);
    if (t <= now) t.setDate(t.getDate() + 1);
    if (!nextDate || t < nextDate) nextDate = t;
  });
  return nextDate;
}

async function scheduleNextPeriodAlarm() {
  await chrome.alarms.clear(ALARM_NAME);
  const date = getNextStartFromNow();
  const when = date.getTime();
  console.log(
    `[${new Date().toLocaleTimeString()}] 다음 알람 예약: ${date.toLocaleString()}`,
  );
  chrome.alarms.create(ALARM_NAME, { when });
}

async function isNotifyOn() {
  const st = await chrome.storage.local.get(STORAGE_KEY_NOTIFY);
  return st[STORAGE_KEY_NOTIFY] !== false;
}

let pollingTimer = null;

let notifiedCardIds = new Set();
let hasFoundInitialData = false;
let previousReportIds = "";

/* 알람 핸들러 */
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM_NAME) return;
  console.log(
    `%c[${new Date().toLocaleTimeString()}] 알람 발생: ${alarm.name}`,
    "color: #28a745; font-weight: bold;",
  );

  if (!(await isNotifyOn())) {
    console.log(
      `[${new Date().toLocaleTimeString()}] 알림이 꺼져있어, 작업을 중단합니다.`,
    );
    return;
  }

  console.log(
    `[${new Date().toLocaleTimeString()}] 새로운 시간대 시작. 상태를 초기화합니다.`,
  );
  notifiedCardIds.clear();
  hasFoundInitialData = false;
  previousReportIds = "";
  if (pollingTimer) clearInterval(pollingTimer);

  await scheduleNextPeriodAlarm();

  console.log(
    `[${new Date().toLocaleTimeString()}] 서버 데이터 확인을 위한 폴링을 시작합니다. (10분 간격)`,
  );

  const poll = async () => {
    console.log(
      `[${new Date().toLocaleTimeString()}] -> 폴링 실행: 서버 데이터 요청...`,
    );
    try {
      const { reports, hits: allHits } = await fetchAndProcessMerchantData();
      const currentReportIds = reports
        ? reports.map((r) => r.id).join(",")
        : "";
      if (currentReportIds === previousReportIds) {
        console.log(
          `[${new Date().toLocaleTimeString()}] <-- 데이터 변경 없음. 건너뜁니다.`,
        );
        return;
      }
      console.log(
        `[${new Date().toLocaleTimeString()}] <-- 새로운 데이터 수신. 총 ${
          allHits.length
        }개의 알림 대상 카드 발견.`,
      );
      previousReportIds = currentReportIds;

      // 기존 카드와 비교하여 새로 추가된 카드 알림 (원하는 로직 유지)
      const newHits = allHits.filter(
        (hit) => !notifiedCardIds.has(hit.uniqueId),
      );
      if (newHits.length > 0) {
        notifyUser(newHits);
        newHits.forEach((hit) => notifiedCardIds.add(hit.uniqueId));

        console.log(
          `[${new Date().toLocaleTimeString()}] 알림 보낸 카드 ID 기록:`,
          newHits.map((h) => h.uniqueId),
        );
      }
    } catch (e) {
      console.warn("폴링 중 오류 발생:", e);
    }
  };

  poll();
  pollingTimer = setInterval(poll, POLLING_INTERVAL);
});

// ===== 신규: 알림 생성 함수 =====
function notifyUser(hits) {
  if (!Array.isArray(hits) || hits.length === 0) return;

  const GRADE_LABELS = {
    5: "에스더",
    4: "전설",
    3: "영웅",
    2: "희귀",
    1: "고급",
    0: "일반",
  };
  const GRADE_ORDER = [5, 4, 3, 2, 1, 0];

  const groups = {};
  for (const hit of hits) {
    const g = hit.grade ?? 0;
    if (!groups[g]) groups[g] = [];
    groups[g].push(hit);
  }

  const lines = [];
  for (const g of GRADE_ORDER) {
    if (!groups[g]) continue;
    const label = GRADE_LABELS[g] || `등급${g}`;
    lines.push(`[${label}]`);
    for (const hit of groups[g]) {
      lines.push(`  ${hit.name} - ${hit.regionName}`);
    }
  }

  chrome.notifications.create(`notification_${Date.now()}`, {
    type: "basic",
    iconUrl: "icons/icon_128.png",
    title: "떠돌이 상인 알림",
    message: lines.join("\n"),
    priority: 2,
  });
}

// ===== 신규: 시작 시 즉시 확인 로직 =====
async function runImmediateCheck() {
  if (!(await isNotifyOn())) {
    console.log(
      `[${new Date().toLocaleTimeString()}] 시작 시 확인: 알림이 꺼져있어 건너뜁니다.`,
    );
    return;
  }

  // 현재 시간이 상인 활동 시간인지 확인
  const now = new Date();
  const currentHour = now.getHours();
  const currentMinute = now.getMinutes();
  const currentTotalMinutes = currentHour * 60 + currentMinute;

  const isActiveNow = TIME_PERIODS.some((period) => {
    const startMinutes = period.start.h * 60 + period.start.m;
    const endMinutes = period.end.h * 60 + period.end.m;
    if (period.nextDay) {
      return (
        currentTotalMinutes >= startMinutes || currentTotalMinutes <= endMinutes
      );
    }
    return (
      currentTotalMinutes >= startMinutes && currentTotalMinutes <= endMinutes
    );
  });

  if (!isActiveNow) {
    console.log(
      `[${new Date().toLocaleTimeString()}] 시작 시 확인: 현재는 상인 활동 시간이 아니므로 건너뜁니다.`,
    );
    return;
  }

  console.log(
    `[${new Date().toLocaleTimeString()}] 시작 시 확인: 현재 활동 시간이므로 즉시 데이터를 확인합니다.`,
  );
  try {
    const { hits } = await fetchAndProcessMerchantData();
    if (hits.length > 0) {
      // 시작 시에는 중복 체크 없이 현재 발견된 모든 카드를 알림
      notifyUser(hits);
    }
  } catch (e) {
    console.warn("시작 시 확인 중 오류 발생:", e);
  }
}

/* 스위치 변경 반영 */
chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== "local" || !(STORAGE_KEY_NOTIFY in changes)) return;
  const enabled = changes[STORAGE_KEY_NOTIFY].newValue !== false;
  console.log(
    `[${new Date().toLocaleTimeString()}] 알림 설정 변경됨: ${
      enabled ? "ON" : "OFF"
    }`,
  );
  if (enabled) {
    await scheduleNextPeriodAlarm();
  } else {
    await chrome.alarms.clear(ALARM_NAME);
    if (pollingTimer) clearInterval(pollingTimer);
  }
});

/* 설치/시작 */
chrome.runtime.onInstalled.addListener(async () => {
  console.log(
    `[${new Date().toLocaleTimeString()}] 확장 프로그램 설치됨/업데이트됨.`,
  );
  const st = await chrome.storage.local.get(STORAGE_KEY_NOTIFY);
  if (typeof st[STORAGE_KEY_NOTIFY] === "undefined") {
    await chrome.storage.local.set({ [STORAGE_KEY_NOTIFY]: false });
    // 알림 설정이 없어서 새로 저장한 경우에는 여기서 알람 예약하지 않음
    // storage.onChanged에서 자동으로 예약됨
  } else {
    await scheduleNextPeriodAlarm();
  }
});
